/**
 * Demonstrates:
 * - Inheritance: Patient extends Person
 * - Polymorphism: Overrides getRole()
 * - Encapsulation: private fields with getters and setters
 */
public class Patient extends Person {
    private int age;
    private String gender;
    private String department;

    public Patient(String id, String name, int age, String gender, String department) {
        super(id, name);
        this.age = age;
        this.gender = gender;
        this.department = department;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    @Override
    public String getRole() {
        return "Patient";
    }
}
