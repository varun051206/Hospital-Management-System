/**
 * Demonstrates:
 * - Encapsulation
 * - State tracking: Present / Absent
 */
public class Attendance {
    private String staffId;
    private String staffName;
    private String status; // "Present" or "Absent"

    public Attendance(String staffId, String staffName, String status) {
        this.staffId = staffId;
        this.staffName = staffName;
        this.status = status;
    }

    public String getStaffId() { return staffId; }
    public String getStaffName() { return staffName; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public boolean isPresent() {
        return "Present".equalsIgnoreCase(status);
    }
}
