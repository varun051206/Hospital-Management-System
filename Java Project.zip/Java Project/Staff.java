/**
 * Demonstrates:
 * - Inheritance: Staff extends Person
 * - Polymorphism: Overrides getRole()
 * - Encapsulation: role field
 */
public class Staff extends Person {
    private String staffRole;

    public Staff(String id, String name, String staffRole) {
        super(id, name);
        this.staffRole = staffRole;
    }

    public String getStaffRole() {
        return staffRole;
    }

    public void setStaffRole(String staffRole) {
        this.staffRole = staffRole;
    }

    @Override
    public String getRole() {
        return staffRole;
    }
}
