/**
 * Demonstrates:
 * - Abstraction: abstract class Person with abstract method getRole()
 * - Encapsulation: protected fields with getters and setters
 */
public abstract class Person {
    protected String id;
    protected String name;

    public Person(String id, String name) {
        this.id = id;
        this.name = name;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    // Abstract method demonstrating Polymorphism in subclasses
    public abstract String getRole();

    @Override
    public String toString() {
        return id + " - " + name + " (" + getRole() + ")";
    }
}
