import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

/**
 * Main Dashboard Screen
 * Demonstrates:
 * - Swing Layout Managers: BorderLayout, GridLayout, FlowLayout
 * - Dynamic data display from HospitalData
 * - Modular navigation across all hospital modules
 */
public class DashboardFrame extends JFrame {
    private JLabel lblPatients = new JLabel();
    private JLabel lblDoctors = new JLabel();
    private JLabel lblStaff = new JLabel();
    private JLabel lblMeds = new JLabel();
    private JLabel lblBeds = new JLabel();
    private JLabel lblBills = new JLabel();

    public DashboardFrame() {
        setTitle("Hospital Management System - Dashboard");
        setSize(800, 520);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        initUI();
        refreshStats();

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowActivated(WindowEvent e) {
                refreshStats();
            }
        });
    }

    private void initUI() {
        JPanel main = new JPanel(new BorderLayout(15, 15));
        main.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        // Header Panel
        JPanel header = new JPanel(new BorderLayout());
        JLabel title = new JLabel("HOSPITAL MANAGEMENT SYSTEM - DASHBOARD");
        title.setFont(new Font("Segoe UI", Font.BOLD, 17));
        title.setForeground(new Color(44, 53, 57));

        JButton btnLogout = new JButton("Logout");
        btnLogout.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new LoginFrame().setVisible(true);
                dispose();
            }
        });

        header.add(title, BorderLayout.WEST);
        header.add(btnLogout, BorderLayout.EAST);
        main.add(header, BorderLayout.NORTH);

        // Center: 6 Summary KPI Cards
        JPanel metrics = new JPanel(new GridLayout(2, 3, 12, 12));
        metrics.add(createCard("Total Patients", lblPatients));
        metrics.add(createCard("Doctors", lblDoctors));
        metrics.add(createCard("Staff", lblStaff));
        metrics.add(createCard("Medicines", lblMeds));
        metrics.add(createCard("Available Beds", lblBeds));
        metrics.add(createCard("Total Invoices", lblBills));
        main.add(metrics, BorderLayout.CENTER);

        // South: Navigation Buttons (2 rows of 4 buttons)
        JPanel nav = new JPanel(new GridLayout(2, 4, 10, 10));
        nav.setBorder(BorderFactory.createTitledBorder("Hospital Modules"));

        nav.add(createNavBtn("Patients", () -> new PatientManagementFrame(this)));
        nav.add(createNavBtn("Doctors", () -> new DoctorManagementFrame(this)));
        nav.add(createNavBtn("Staff", () -> new StaffManagementFrame(this)));
        nav.add(createNavBtn("Pharmacy", () -> new PharmacyFrame(this)));
        nav.add(createNavBtn("Room & Beds", () -> new RoomBedFrame(this)));
        nav.add(createNavBtn("Billing", () -> new BillingFrame(this)));
        nav.add(createNavBtn("Attendance", () -> new AttendanceFrame(this)));
        nav.add(createNavBtn("Reports", () -> new ReportsFrame(this)));

        main.add(nav, BorderLayout.SOUTH);
        add(main);
    }

    private JPanel createCard(String title, JLabel valueLabel) {
        JPanel card = new JPanel(new GridLayout(2, 1, 4, 4));
        card.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(210, 215, 220)),
            BorderFactory.createEmptyBorder(8, 12, 8, 12)
        ));
        card.setBackground(Color.WHITE);

        JLabel lbl = new JLabel(title);
        lbl.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        lbl.setForeground(new Color(100, 100, 100));

        valueLabel.setFont(new Font("Segoe UI", Font.BOLD, 22));
        valueLabel.setForeground(new Color(44, 53, 57));

        card.add(lbl);
        card.add(valueLabel);
        return card;
    }

    private JButton createNavBtn(String text, FrameOpener opener) {
        JButton btn = new JButton(text);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btn.setFocusPainted(false);
        btn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                opener.open().setVisible(true);
                setVisible(false);
            }
        });
        return btn;
    }

    public void refreshStats() {
        lblPatients.setText(String.valueOf(HospitalData.getPatientCount()));
        lblDoctors.setText(String.valueOf(HospitalData.getDoctorCount()));
        lblStaff.setText(String.valueOf(HospitalData.getStaffCount()));
        lblMeds.setText(String.valueOf(HospitalData.getMedicineCount()));
        lblBeds.setText(HospitalData.getAvailableBedCount() + " / " + HospitalData.getBedCount());
        lblBills.setText(String.valueOf(HospitalData.getBillCount()));
    }

    // Simple functional interface for concise frame opening
    interface FrameOpener {
        JFrame open();
    }
}
