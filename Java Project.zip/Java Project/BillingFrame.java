import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

/**
 * Billing & Invoicing Screen
 * Demonstrates:
 * - Simple formula: Total = Consultation + Room + Medicine
 * - Exception Handling: NumberFormatException on currency inputs
 * - Swing GUI: Form and JTable integration
 */
public class BillingFrame extends JFrame {
    private DashboardFrame dashboard;

    private JTextField txtBillId = new JTextField();
    private JTextField txtPatientId = new JTextField();
    private JTextField txtConsult = new JTextField("500");
    private JTextField txtRoom = new JTextField("1000");
    private JTextField txtMedicine = new JTextField("750");
    private JLabel lblTotal = new JLabel("₹0.00");

    private DefaultTableModel tableModel;
    private JTable table;

    public BillingFrame(DashboardFrame dashboard) {
        this.dashboard = dashboard;
        setTitle("Hospital Management System - Billing");
        setSize(880, 520);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        initUI();
        loadTable();
    }

    private void initUI() {
        JPanel main = new JPanel(new BorderLayout(10, 10));
        main.setBorder(BorderFactory.createEmptyBorder(10, 15, 10, 15));

        // Header
        JPanel top = new JPanel(new BorderLayout());
        JLabel lblTitle = new JLabel("HOSPITAL BILLING & INVOICING MODULE");
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 16));

        JButton btnBack = new JButton("<< Back to Dashboard");
        btnBack.addActionListener(e -> {
            if (dashboard != null) {
                dashboard.refreshStats();
                dashboard.setVisible(true);
            }
            dispose();
        });

        top.add(lblTitle, BorderLayout.WEST);
        top.add(btnBack, BorderLayout.EAST);
        main.add(top, BorderLayout.NORTH);

        // Center Split
        JPanel body = new JPanel(new BorderLayout(15, 10));

        // Left Form
        JPanel formCard = new JPanel(new BorderLayout());
        formCard.setPreferredSize(new Dimension(300, 380));
        formCard.setBorder(BorderFactory.createTitledBorder("Bill Details"));

        JPanel formFields = new JPanel(new GridLayout(6, 2, 8, 10));
        formFields.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        txtBillId.setText("B00" + (HospitalData.getBillCount() + 1));

        formFields.add(new JLabel("Bill ID:"));
        formFields.add(txtBillId);
        formFields.add(new JLabel("Patient ID:"));
        formFields.add(txtPatientId);
        formFields.add(new JLabel("Consultation (₹):"));
        formFields.add(txtConsult);
        formFields.add(new JLabel("Room Fee (₹):"));
        formFields.add(txtRoom);
        formFields.add(new JLabel("Medicine Fee (₹):"));
        formFields.add(txtMedicine);
        formFields.add(new JLabel("Total Calculated:"));
        lblTotal.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lblTotal.setForeground(new Color(30, 120, 60));
        formFields.add(lblTotal);
        formCard.add(formFields, BorderLayout.CENTER);

        JPanel formBtns = new JPanel(new GridLayout(3, 1, 6, 6));
        JButton btnCalculate = new JButton("Calculate Total");
        JButton btnGenerate = new JButton("Generate Bill");
        JButton btnClear = new JButton("Clear Form");

        formBtns.add(btnCalculate);
        formBtns.add(btnGenerate);
        formBtns.add(btnClear);
        formCard.add(formBtns, BorderLayout.SOUTH);

        body.add(formCard, BorderLayout.WEST);

        // Right Table
        JPanel tableCard = new JPanel(new BorderLayout(8, 8));
        tableCard.setBorder(BorderFactory.createTitledBorder("Generated Bills"));

        String[] cols = { "Bill ID", "Patient ID", "Consult (₹)", "Room (₹)", "Med (₹)", "Total (₹)" };
        tableModel = new DefaultTableModel(cols, 0) {
            @Override
            public boolean isCellEditable(int r, int c) { return false; }
        };
        table = new JTable(tableModel);
        tableCard.add(new JScrollPane(table), BorderLayout.CENTER);

        body.add(tableCard, BorderLayout.CENTER);
        main.add(body, BorderLayout.CENTER);

        // Action Listeners
        btnCalculate.addActionListener(e -> calculateTotal());
        btnGenerate.addActionListener(e -> generateBill());
        btnClear.addActionListener(e -> clearForm());

        add(main);
    }

    private double calculateTotal() {
        try {
            double c = Double.parseDouble(txtConsult.getText().trim());
            double r = Double.parseDouble(txtRoom.getText().trim());
            double m = Double.parseDouble(txtMedicine.getText().trim());

            if (c < 0 || r < 0 || m < 0) {
                JOptionPane.showMessageDialog(this, "Amounts cannot be negative.", "Error", JOptionPane.WARNING_MESSAGE);
                return -1;
            }

            double total = c + r + m;
            lblTotal.setText(String.format("₹%.2f", total));
            return total;
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Enter valid numbers for all charges.", "Error", JOptionPane.ERROR_MESSAGE);
            return -1;
        }
    }

    private void generateBill() {
        String billId = txtBillId.getText().trim();
        String pId = txtPatientId.getText().trim();

        if (billId.isEmpty() || pId.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter Bill ID and Patient ID.", "Validation Error", JOptionPane.WARNING_MESSAGE);
            return;
        }

        double total = calculateTotal();
        if (total < 0) return;

        double c = Double.parseDouble(txtConsult.getText().trim());
        double r = Double.parseDouble(txtRoom.getText().trim());
        double m = Double.parseDouble(txtMedicine.getText().trim());

        HospitalData.addBill(new Bill(billId, pId, c, r, m));
        loadTable();
        JOptionPane.showMessageDialog(this, "Bill " + billId + " generated! Total: ₹" + total, "Success", JOptionPane.INFORMATION_MESSAGE);
        clearForm();
    }

    private void loadTable() {
        tableModel.setRowCount(0);
        for (Bill b : HospitalData.getBills()) {
            tableModel.addRow(new Object[] {
                b.getBillId(), b.getPatientId(),
                String.format("%.2f", b.getConsultationCharge()),
                String.format("%.2f", b.getRoomCharge()),
                String.format("%.2f", b.getMedicineCharge()),
                String.format("%.2f", b.getTotalAmount())
            });
        }
    }

    private void clearForm() {
        txtPatientId.setText("");
        txtConsult.setText("500");
        txtRoom.setText("1000");
        txtMedicine.setText("750");
        lblTotal.setText("₹0.00");
        txtBillId.setText("B00" + (HospitalData.getBillCount() + 1));
    }
}
