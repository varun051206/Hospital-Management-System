import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

/**
 * Room & Bed Management Screen
 * Demonstrates:
 * - State Management: Allocate Bed (Available -> Occupied), Release Bed (Occupied -> Available)
 * - Swing GUI: JTable, JButton, JOptionPane
 */
public class RoomBedFrame extends JFrame {
    private DashboardFrame dashboard;

    private DefaultTableModel tableModel;
    private JTable table;
    private JLabel lblStatus = new JLabel();

    public RoomBedFrame(DashboardFrame dashboard) {
        this.dashboard = dashboard;
        setTitle("Hospital Management System - Room & Bed Allocation");
        setSize(750, 480);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        initUI();
        loadTable();
    }

    private void initUI() {
        JPanel main = new JPanel(new BorderLayout(10, 10));
        main.setBorder(BorderFactory.createEmptyBorder(10, 15, 10, 15));

        // Header
        JPanel top = new JPanel(new BorderLayout());
        JLabel lblTitle = new JLabel("ROOM & BED ALLOCATION MODULE");
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 16));

        JButton btnBack = new JButton("<< Back to Dashboard");
        btnBack.addActionListener(e -> {
            if (dashboard != null) {
                dashboard.refreshStats();
                dashboard.setVisible(true);
            }
            dispose();
        });

        top.add(lblTitle, BorderLayout.WEST);
        top.add(btnBack, BorderLayout.EAST);
        main.add(top, BorderLayout.NORTH);

        // Center Table Card
        JPanel tableCard = new JPanel(new BorderLayout(8, 8));
        tableCard.setBorder(BorderFactory.createTitledBorder("Hospital Beds Status"));

        tableModel = new DefaultTableModel(new String[] { "Room Number", "Bed Number", "Status" }, 0) {
            @Override
            public boolean isCellEditable(int r, int c) { return false; }
        };
        table = new JTable(tableModel);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        tableCard.add(new JScrollPane(table), BorderLayout.CENTER);

        // Bottom Controls
        JPanel bottom = new JPanel(new BorderLayout());
        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 8));

        JButton btnAllocate = new JButton("Allocate Bed");
        JButton btnRelease = new JButton("Release Bed");
        JButton btnRefresh = new JButton("Refresh");

        btnAllocate.setBackground(new Color(40, 120, 70));
        btnAllocate.setForeground(Color.WHITE);
        btnRelease.setBackground(new Color(190, 80, 30));
        btnRelease.setForeground(Color.WHITE);

        btnPanel.add(btnAllocate);
        btnPanel.add(btnRelease);
        btnPanel.add(btnRefresh);

        lblStatus.setFont(new Font("Segoe UI", Font.BOLD, 12));
        lblStatus.setHorizontalAlignment(JLabel.CENTER);

        bottom.add(lblStatus, BorderLayout.NORTH);
        bottom.add(btnPanel, BorderLayout.SOUTH);
        tableCard.add(bottom, BorderLayout.SOUTH);

        main.add(tableCard, BorderLayout.CENTER);

        // Actions
        btnAllocate.addActionListener(e -> handleAllocate());
        btnRelease.addActionListener(e -> handleRelease());
        btnRefresh.addActionListener(e -> loadTable());

        add(main);
    }

    private void loadTable() {
        tableModel.setRowCount(0);
        for (Bed b : HospitalData.getBeds()) {
            tableModel.addRow(new Object[] { b.getRoomNumber(), b.getBedNumber(), b.getStatus() });
        }
        lblStatus.setText("Total Beds: " + HospitalData.getBedCount() + 
            " | Available: " + HospitalData.getAvailableBedCount() + 
            " | Occupied: " + HospitalData.getOccupiedBedCount());
    }

    private void handleAllocate() {
        int row = table.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(this, "Select a bed row from the table.", "Selection Required", JOptionPane.WARNING_MESSAGE);
            return;
        }

        String room = tableModel.getValueAt(row, 0).toString();
        String bed = tableModel.getValueAt(row, 1).toString();
        String status = tableModel.getValueAt(row, 2).toString();

        if ("Occupied".equalsIgnoreCase(status)) {
            JOptionPane.showMessageDialog(this, "Bed " + bed + " is ALREADY OCCUPIED!", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        int ok = JOptionPane.showConfirmDialog(this, "Allocate " + bed + " in Room " + room + "?", "Confirm", JOptionPane.YES_NO_OPTION);
        if (ok == JOptionPane.YES_OPTION) {
            HospitalData.allocateBed(room, bed);
            loadTable();
            JOptionPane.showMessageDialog(this, "Bed allocated successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    private void handleRelease() {
        int row = table.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(this, "Select a bed row from the table.", "Selection Required", JOptionPane.WARNING_MESSAGE);
            return;
        }

        String room = tableModel.getValueAt(row, 0).toString();
        String bed = tableModel.getValueAt(row, 1).toString();
        String status = tableModel.getValueAt(row, 2).toString();

        if ("Available".equalsIgnoreCase(status)) {
            JOptionPane.showMessageDialog(this, "Bed " + bed + " is ALREADY AVAILABLE!", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        int ok = JOptionPane.showConfirmDialog(this, "Discharge patient and release " + bed + "?", "Confirm", JOptionPane.YES_NO_OPTION);
        if (ok == JOptionPane.YES_OPTION) {
            HospitalData.releaseBed(room, bed);
            loadTable();
            JOptionPane.showMessageDialog(this, "Bed released to Available.", "Success", JOptionPane.INFORMATION_MESSAGE);
        }
    }
}
