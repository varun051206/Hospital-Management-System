import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.ArrayList;

/**
 * Pharmacy & Medicine Stock Screen
 * Demonstrates:
 * - Swing GUI: JTextField, JTable, JButton, JOptionPane
 * - Exception Handling: NumberFormatException on numeric fields
 * - Inventory tracking: Stock In (+), Stock Out (-), and Low Stock (< 20) check
 */
public class PharmacyFrame extends JFrame {
    private DashboardFrame dashboard;

    private JTextField txtId = new JTextField();
    private JTextField txtName = new JTextField();
    private JTextField txtQty = new JTextField();
    private JTextField txtPrice = new JTextField();
    private JTextField txtStockChange = new JTextField(6);
    private JTextField txtSearch = new JTextField(10);

    private DefaultTableModel tableModel;
    private JTable table;

    public PharmacyFrame(DashboardFrame dashboard) {
        this.dashboard = dashboard;
        setTitle("Hospital Management System - Pharmacy & Stock");
        setSize(900, 540);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        initUI();
        loadTable(HospitalData.getMedicines());
    }

    private void initUI() {
        JPanel main = new JPanel(new BorderLayout(10, 10));
        main.setBorder(BorderFactory.createEmptyBorder(10, 15, 10, 15));

        // Header
        JPanel top = new JPanel(new BorderLayout());
        JLabel lblTitle = new JLabel("PHARMACY & MEDICINE STOCK MODULE");
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 16));

        JButton btnBack = new JButton("<< Back to Dashboard");
        btnBack.addActionListener(e -> {
            if (dashboard != null) {
                dashboard.refreshStats();
                dashboard.setVisible(true);
            }
            dispose();
        });

        top.add(lblTitle, BorderLayout.WEST);
        top.add(btnBack, BorderLayout.EAST);
        main.add(top, BorderLayout.NORTH);

        // Center split
        JPanel body = new JPanel(new BorderLayout(15, 10));

        // Form Card
        JPanel formCard = new JPanel(new BorderLayout());
        formCard.setPreferredSize(new Dimension(300, 400));
        formCard.setBorder(BorderFactory.createTitledBorder("Medicine Form"));

        JPanel formFields = new JPanel(new GridLayout(5, 2, 8, 10));
        formFields.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        formFields.add(new JLabel("Medicine ID:"));
        formFields.add(txtId);
        formFields.add(new JLabel("Name:"));
        formFields.add(txtName);
        formFields.add(new JLabel("Quantity:"));
        formFields.add(txtQty);
        formFields.add(new JLabel("Price (₹):"));
        formFields.add(txtPrice);
        formFields.add(new JLabel("Stock In/Out:"));
        formFields.add(txtStockChange);
        formCard.add(formFields, BorderLayout.CENTER);

        // Form Action Buttons
        JPanel formBtns = new JPanel(new GridLayout(3, 2, 6, 6));
        JButton btnAdd = new JButton("Add");
        JButton btnUpdate = new JButton("Update");
        JButton btnStockIn = new JButton("Stock In (+)");
        JButton btnStockOut = new JButton("Stock Out (-)");
        JButton btnDelete = new JButton("Delete");
        JButton btnClear = new JButton("Clear");

        formBtns.add(btnAdd);
        formBtns.add(btnUpdate);
        formBtns.add(btnStockIn);
        formBtns.add(btnStockOut);
        formBtns.add(btnDelete);
        formBtns.add(btnClear);
        formCard.add(formBtns, BorderLayout.SOUTH);

        body.add(formCard, BorderLayout.WEST);

        // Table Card
        JPanel tableCard = new JPanel(new BorderLayout(8, 8));
        tableCard.setBorder(BorderFactory.createTitledBorder("Medicine Inventory"));

        JPanel searchBar = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 4));
        JButton btnSearch = new JButton("Search");
        JButton btnShowAll = new JButton("Show All");
        searchBar.add(new JLabel("Search:"));
        searchBar.add(txtSearch);
        searchBar.add(btnSearch);
        searchBar.add(btnShowAll);
        tableCard.add(searchBar, BorderLayout.NORTH);

        tableModel = new DefaultTableModel(new String[] { "ID", "Name", "Qty", "Price (₹)", "Status" }, 0) {
            @Override
            public boolean isCellEditable(int r, int c) { return false; }
        };
        table = new JTable(tableModel);
        tableCard.add(new JScrollPane(table), BorderLayout.CENTER);

        body.add(tableCard, BorderLayout.CENTER);
        main.add(body, BorderLayout.CENTER);

        // Row click fills form
        table.getSelectionModel().addListSelectionListener(e -> {
            int row = table.getSelectedRow();
            if (row != -1) {
                txtId.setText(tableModel.getValueAt(row, 0).toString());
                txtName.setText(tableModel.getValueAt(row, 1).toString());
                txtQty.setText(tableModel.getValueAt(row, 2).toString());
                txtPrice.setText(tableModel.getValueAt(row, 3).toString());
            }
        });

        // Button Listeners
        btnAdd.addActionListener(e -> addMedicine());
        btnUpdate.addActionListener(e -> updateMedicine());
        btnDelete.addActionListener(e -> deleteMedicine());
        btnStockIn.addActionListener(e -> adjustStock(true));
        btnStockOut.addActionListener(e -> adjustStock(false));
        btnClear.addActionListener(e -> clearForm());
        btnSearch.addActionListener(e -> {
            String q = txtSearch.getText().trim();
            loadTable(q.isEmpty() ? HospitalData.getMedicines() : HospitalData.searchMedicines(q));
        });
        btnShowAll.addActionListener(e -> {
            txtSearch.setText("");
            loadTable(HospitalData.getMedicines());
        });

        add(main);
    }

    private void loadTable(ArrayList<Medicine> list) {
        tableModel.setRowCount(0);
        for (Medicine m : list) {
            tableModel.addRow(new Object[] {
                m.getId(), m.getName(), m.getQuantity(), String.format("%.2f", m.getPrice()), m.getStatus()
            });
        }
    }

    private void addMedicine() {
        String id = txtId.getText().trim();
        String name = txtName.getText().trim();

        if (id.isEmpty() || name.isEmpty() || txtQty.getText().isEmpty() || txtPrice.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill in all medicine fields.", "Validation Error", JOptionPane.WARNING_MESSAGE);
            return;
        }
        if (HospitalData.medicineIdExists(id)) {
            JOptionPane.showMessageDialog(this, "Medicine ID already exists!", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try {
            int qty = Integer.parseInt(txtQty.getText().trim());
            double price = Double.parseDouble(txtPrice.getText().trim());
            if (qty < 0 || price < 0) {
                JOptionPane.showMessageDialog(this, "Quantity and Price must be positive.", "Error", JOptionPane.WARNING_MESSAGE);
                return;
            }

            HospitalData.addMedicine(new Medicine(id, name, qty, price));
            loadTable(HospitalData.getMedicines());
            clearForm();
            JOptionPane.showMessageDialog(this, "Medicine added successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Quantity and Price must be numeric.", "Number Format Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void updateMedicine() {
        String id = txtId.getText().trim();
        String name = txtName.getText().trim();

        if (!HospitalData.medicineIdExists(id)) {
            JOptionPane.showMessageDialog(this, "Select an existing medicine to update.", "Error", JOptionPane.WARNING_MESSAGE);
            return;
        }

        try {
            int qty = Integer.parseInt(txtQty.getText().trim());
            double price = Double.parseDouble(txtPrice.getText().trim());
            HospitalData.updateMedicine(new Medicine(id, name, qty, price));
            loadTable(HospitalData.getMedicines());
            JOptionPane.showMessageDialog(this, "Medicine updated.", "Success", JOptionPane.INFORMATION_MESSAGE);
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Enter valid numbers for Qty and Price.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void deleteMedicine() {
        String id = txtId.getText().trim();
        if (!HospitalData.medicineIdExists(id)) {
            JOptionPane.showMessageDialog(this, "Select a valid medicine to delete.", "Error", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int ok = JOptionPane.showConfirmDialog(this, "Delete medicine " + id + "?", "Confirm", JOptionPane.YES_NO_OPTION);
        if (ok == JOptionPane.YES_OPTION) {
            HospitalData.deleteMedicine(id);
            loadTable(HospitalData.getMedicines());
            clearForm();
            JOptionPane.showMessageDialog(this, "Medicine deleted.", "Deleted", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    private void adjustStock(boolean isStockIn) {
        String id = txtId.getText().trim();
        String changeStr = txtStockChange.getText().trim();

        if (!HospitalData.medicineIdExists(id)) {
            JOptionPane.showMessageDialog(this, "Select a medicine first.", "Error", JOptionPane.WARNING_MESSAGE);
            return;
        }

        try {
            int change = Integer.parseInt(changeStr);
            if (change <= 0) {
                JOptionPane.showMessageDialog(this, "Amount must be greater than zero.", "Error", JOptionPane.WARNING_MESSAGE);
                return;
            }

            if (isStockIn) {
                HospitalData.stockIn(id, change);
                JOptionPane.showMessageDialog(this, "Added " + change + " units to stock.", "Stock In", JOptionPane.INFORMATION_MESSAGE);
            } else {
                boolean success = HospitalData.stockOut(id, change);
                if (!success) {
                    JOptionPane.showMessageDialog(this, "Insufficient stock! Cannot reduce below 0.", "Stock Out Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                JOptionPane.showMessageDialog(this, "Removed " + change + " units from stock.", "Stock Out", JOptionPane.INFORMATION_MESSAGE);
            }

            loadTable(HospitalData.getMedicines());
            txtStockChange.setText("");
            // Update quantity field in form
            for (Medicine m : HospitalData.getMedicines()) {
                if (m.getId().equalsIgnoreCase(id)) {
                    txtQty.setText(String.valueOf(m.getQuantity()));
                    break;
                }
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Enter a valid numeric quantity.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void clearForm() {
        txtId.setText("");
        txtName.setText("");
        txtQty.setText("");
        txtPrice.setText("");
        txtStockChange.setText("");
        table.clearSelection();
        txtId.requestFocus();
    }
}
