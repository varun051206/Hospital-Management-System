import javax.swing.*;

/**
 * Course: CS25C09 - JAVA Programming
 * Team 12 | AI&DS / II B / III
 * Project: Hospital Management System (Batch 1)
 * Academic Year: 2026-2027 (Odd)
 *
 * Main Application Entry Point
 * Demonstrates:
 * - Application launching via main() method
 * - SwingUtilities.invokeLater() for thread-safe GUI invocation
 * - System Look and Feel configuration
 */
public class Main {
    public static void main(String[] args) {
        // Set native system look and feel for a clean and professional appearance
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            System.err.println("Could not set system look and feel: " + e.getMessage());
        }

        // Launch Login Frame on the Event Dispatch Thread (EDT)
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                LoginFrame login = new LoginFrame();
                login.setVisible(true);
            }
        });
    }
}
