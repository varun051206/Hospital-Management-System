import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * Login Screen for Hospital Management System
 * Demonstrates:
 * - Swing GUI: JFrame, JPanel, JTextField, JPasswordField, JButton
 * - Event Handling: ActionListener on buttons
 */
public class LoginFrame extends JFrame {
    private JTextField txtUser;
    private JPasswordField txtPass;

    public LoginFrame() {
        setTitle("Hospital Management System - Login");
        setSize(400, 280);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);

        initUI();
    }

    private void initUI() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(15, 20, 15, 20));

        // Header
        JLabel lblTitle = new JLabel("Hospital Management System", JLabel.CENTER);
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 16));
        lblTitle.setForeground(new Color(44, 53, 57));
        panel.add(lblTitle, BorderLayout.NORTH);

        // Form
        JPanel form = new JPanel(new GridLayout(2, 2, 10, 15));
        form.setBorder(BorderFactory.createEmptyBorder(20, 10, 10, 10));

        form.add(new JLabel("Username:"));
        txtUser = new JTextField();
        form.add(txtUser);

        form.add(new JLabel("Password:"));
        txtPass = new JPasswordField();
        form.add(txtPass);

        panel.add(form, BorderLayout.CENTER);

        // Buttons
        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 10));
        JButton btnLogin = new JButton("Login");
        JButton btnClear = new JButton("Clear");

        btnLogin.setBackground(new Color(44, 53, 57));
        btnLogin.setForeground(Color.WHITE);

        btnPanel.add(btnLogin);
        btnPanel.add(btnClear);
        panel.add(btnPanel, BorderLayout.SOUTH);

        // Event Handling
        btnLogin.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String user = txtUser.getText().trim();
                String pass = new String(txtPass.getPassword()).trim();

                // Authentication check
                if (user.equals("admin") && pass.equals("admin123")) {
                    new DashboardFrame().setVisible(true);
                    dispose();
                } else {
                    JOptionPane.showMessageDialog(LoginFrame.this,
                        "Invalid Username or Password!\nDefault: admin / admin123",
                        "Login Failed", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        btnClear.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                txtUser.setText("");
                txtPass.setText("");
                txtUser.requestFocus();
            }
        });

        getRootPane().setDefaultButton(btnLogin);
        add(panel);
    }
}
