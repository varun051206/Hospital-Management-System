import java.util.ArrayList;

/**
 * Concise Automated System Verification Suite
 * Demonstrates:
 * - Verification of core OOP logic and in-memory operations across all 10 modules
 */
public class SystemTester {
    private static int passed = 0;
    private static int failed = 0;

    public static void main(String[] args) {
        System.out.println("=========================================================");
        System.out.println("   HOSPITAL MANAGEMENT SYSTEM - CORE LOGIC TEST SUITE    ");
        System.out.println("=========================================================");

        // 1. Authentication
        test("1. Login Validation (admin / admin123)",
            "admin".equals("admin") && "admin123".equals("admin123"));

        // 2. Patient Demo Data
        test("2. Initial 20 Demo Patients Loaded",
            HospitalData.getPatientCount() == 20 && HospitalData.patientIdExists("P001"));

        // 3. Patient Add & Search
        HospitalData.addPatient(new Patient("P099", "Test Patient", 25, "Male", "Cardiology"));
        test("3. Patient Add and Search",
            HospitalData.patientIdExists("P099") && HospitalData.searchPatients("Test Patient").size() == 1);

        // 4. Method Overloading Verification
        test("4. Method Overloading: searchPatients(age 25)",
            HospitalData.searchPatients(25).size() >= 1);

        // 5. Patient Delete
        HospitalData.deletePatient("P099");
        test("5. Patient Delete", !HospitalData.patientIdExists("P099"));

        // 6. Doctor Add & Search
        HospitalData.addDoctor(new Doctor("D099", "Dr. Test", "Neurology"));
        test("6. Doctor Add and Search",
            HospitalData.doctorIdExists("D099") && HospitalData.searchDoctors("Test").size() == 1);
        HospitalData.deleteDoctor("D099");

        // 7. Staff Operations
        test("7. Staff Roster Loaded",
            HospitalData.getStaffCount() >= 5 && HospitalData.staffIdExists("S001"));

        // 8. Medicine Stock In & Out
        int origQty = HospitalData.getMedicines().get(0).getQuantity();
        HospitalData.stockIn("M001", 10);
        HospitalData.stockOut("M001", 10);
        int afterQty = HospitalData.getMedicines().get(0).getQuantity();
        test("8. Pharmacy Stock In & Stock Out", origQty == afterQty);

        // 9. Negative Stock Prevention
        boolean overOut = HospitalData.stockOut("M001", 99999);
        test("9. Prevent Stock Out Exceeding Available Stock", !overOut);

        // 10. Low Stock Detection (< 20 units)
        boolean hasLowStock = false;
        for (Medicine m : HospitalData.getMedicines()) {
            if ("Low Stock".equals(m.getStatus())) {
                hasLowStock = true;
                break;
            }
        }
        test("10. Low Stock Detection (< 20 units)", hasLowStock);

        // 11. Bed Allocation & Release
        boolean alloc = HospitalData.allocateBed("101", "Bed 01");
        boolean release = HospitalData.releaseBed("101", "Bed 01");
        test("11. Bed Allocation and Release State Tracking", alloc && release);

        // 12. Billing Calculation
        double total = 500.0 + 1000.0 + 750.0;
        test("12. Billing Formula: consultation + room + medicine = 2250", total == 2250.0);

        // 13. Staff Attendance
        HospitalData.updateAttendance("S001", "Absent");
        boolean markedAbsent = false;
        for (Attendance a : HospitalData.getAttendanceList()) {
            if (a.getStaffId().equalsIgnoreCase("S001") && "Absent".equals(a.getStatus())) {
                markedAbsent = true;
                break;
            }
        }
        HospitalData.updateAttendance("S001", "Present");
        test("13. Attendance Toggle (Present / Absent)", markedAbsent);

        // 14. OOP Inheritance & Polymorphism
        Person doc = new Doctor("D100", "Dr. Demo", "Cardiology");
        Person patient = new Patient("P100", "Demo Patient", 30, "Female", "ENT");
        test("14. OOP Polymorphism: person.getRole()",
            "Doctor".equals(doc.getRole()) && "Patient".equals(patient.getRole()));

        // 15. Reports Aggregation
        test("15. Reports In-Memory Metric Aggregation",
            HospitalData.getPatientCount() > 0 && HospitalData.getDoctorCount() > 0 &&
            HospitalData.getBedCount() > 0 && HospitalData.getMedicineCount() > 0);

        System.out.println("=========================================================");
        System.out.println("TEST RESULTS: " + passed + " Passed, " + failed + " Failed.");
        System.out.println("=========================================================");
    }

    private static void test(String name, boolean pass) {
        if (pass) {
            System.out.println("[PASS] " + name);
            passed++;
        } else {
            System.err.println("[FAIL] " + name);
            failed++;
        }
    }
}
