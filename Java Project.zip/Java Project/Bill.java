/**
 * Demonstrates:
 * - Encapsulation
 * - Calculation of total bill amount (consultation + room + medicine)
 */
public class Bill {
    private String billId;
    private String patientId;
    private double consultationCharge;
    private double roomCharge;
    private double medicineCharge;
    private double totalAmount;

    public Bill(String billId, String patientId, double consultation, double room, double medicine) {
        this.billId = billId;
        this.patientId = patientId;
        this.consultationCharge = consultation;
        this.roomCharge = room;
        this.medicineCharge = medicine;
        this.totalAmount = consultation + room + medicine;
    }

    public String getBillId() { return billId; }
    public String getPatientId() { return patientId; }
    public double getConsultationCharge() { return consultationCharge; }
    public double getRoomCharge() { return roomCharge; }
    public double getMedicineCharge() { return medicineCharge; }
    public double getTotalAmount() { return totalAmount; }
}
