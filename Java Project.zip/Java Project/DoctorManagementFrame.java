import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.ArrayList;

/**
 * Doctor Management Screen
 * Demonstrates:
 * - Swing GUI: JTextField, JTable, JButton
 * - Event Handling: ActionListener on CRUD buttons
 * - In-Memory operations on ArrayList<Doctor>
 */
public class DoctorManagementFrame extends JFrame {
    private DashboardFrame dashboard;

    private JTextField txtId = new JTextField();
    private JTextField txtName = new JTextField();
    private JTextField txtSpec = new JTextField();
    private JTextField txtSearch = new JTextField(12);

    private DefaultTableModel tableModel;
    private JTable table;

    public DoctorManagementFrame(DashboardFrame dashboard) {
        this.dashboard = dashboard;
        setTitle("Hospital Management System - Doctor Management");
        setSize(850, 500);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        initUI();
        loadTable(HospitalData.getDoctors());
    }

    private void initUI() {
        JPanel main = new JPanel(new BorderLayout(10, 10));
        main.setBorder(BorderFactory.createEmptyBorder(10, 15, 10, 15));

        // Header
        JPanel top = new JPanel(new BorderLayout());
        JLabel lblTitle = new JLabel("DOCTOR MANAGEMENT MODULE");
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 16));

        JButton btnBack = new JButton("<< Back to Dashboard");
        btnBack.addActionListener(e -> {
            if (dashboard != null) {
                dashboard.refreshStats();
                dashboard.setVisible(true);
            }
            dispose();
        });

        top.add(lblTitle, BorderLayout.WEST);
        top.add(btnBack, BorderLayout.EAST);
        main.add(top, BorderLayout.NORTH);

        // Center: Form Left, Table Right
        JPanel body = new JPanel(new BorderLayout(15, 10));

        // Form Card
        JPanel formCard = new JPanel(new BorderLayout());
        formCard.setPreferredSize(new Dimension(280, 350));
        formCard.setBorder(BorderFactory.createTitledBorder("Doctor Form"));

        JPanel formFields = new JPanel(new GridLayout(3, 2, 8, 12));
        formFields.setBorder(BorderFactory.createEmptyBorder(15, 10, 15, 10));
        formFields.add(new JLabel("Doctor ID:"));
        formFields.add(txtId);
        formFields.add(new JLabel("Name:"));
        formFields.add(txtName);
        formFields.add(new JLabel("Specialization:"));
        formFields.add(txtSpec);
        formCard.add(formFields, BorderLayout.CENTER);

        JPanel formBtns = new JPanel(new GridLayout(2, 2, 6, 6));
        JButton btnAdd = new JButton("Add");
        JButton btnUpdate = new JButton("Update");
        JButton btnDelete = new JButton("Delete");
        JButton btnClear = new JButton("Clear");

        formBtns.add(btnAdd);
        formBtns.add(btnUpdate);
        formBtns.add(btnDelete);
        formBtns.add(btnClear);
        formCard.add(formBtns, BorderLayout.SOUTH);

        body.add(formCard, BorderLayout.WEST);

        // Table Card
        JPanel tableCard = new JPanel(new BorderLayout(8, 8));
        tableCard.setBorder(BorderFactory.createTitledBorder("Doctor Directory"));

        JPanel searchBar = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 4));
        JButton btnSearch = new JButton("Search");
        JButton btnShowAll = new JButton("Show All");
        searchBar.add(new JLabel("Search:"));
        searchBar.add(txtSearch);
        searchBar.add(btnSearch);
        searchBar.add(btnShowAll);
        tableCard.add(searchBar, BorderLayout.NORTH);

        tableModel = new DefaultTableModel(new String[] { "ID", "Name", "Specialization" }, 0) {
            @Override
            public boolean isCellEditable(int r, int c) { return false; }
        };
        table = new JTable(tableModel);
        tableCard.add(new JScrollPane(table), BorderLayout.CENTER);

        body.add(tableCard, BorderLayout.CENTER);
        main.add(body, BorderLayout.CENTER);

        // Click row fills form
        table.getSelectionModel().addListSelectionListener(e -> {
            int row = table.getSelectedRow();
            if (row != -1) {
                txtId.setText(tableModel.getValueAt(row, 0).toString());
                txtName.setText(tableModel.getValueAt(row, 1).toString());
                txtSpec.setText(tableModel.getValueAt(row, 2).toString());
            }
        });

        // Button Actions
        btnAdd.addActionListener(e -> {
            String id = txtId.getText().trim();
            String name = txtName.getText().trim();
            String spec = txtSpec.getText().trim();

            if (id.isEmpty() || name.isEmpty() || spec.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please fill in all fields.", "Error", JOptionPane.WARNING_MESSAGE);
                return;
            }
            if (HospitalData.doctorIdExists(id)) {
                JOptionPane.showMessageDialog(this, "Doctor ID already exists!", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            HospitalData.addDoctor(new Doctor(id, name, spec));
            loadTable(HospitalData.getDoctors());
            clearForm();
            JOptionPane.showMessageDialog(this, "Doctor added successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
        });

        btnUpdate.addActionListener(e -> {
            String id = txtId.getText().trim();
            String name = txtName.getText().trim();
            String spec = txtSpec.getText().trim();

            if (!HospitalData.doctorIdExists(id)) {
                JOptionPane.showMessageDialog(this, "Doctor ID not found.", "Error", JOptionPane.WARNING_MESSAGE);
                return;
            }

            HospitalData.updateDoctor(new Doctor(id, name, spec));
            loadTable(HospitalData.getDoctors());
            JOptionPane.showMessageDialog(this, "Doctor updated successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
        });

        btnDelete.addActionListener(e -> {
            String id = txtId.getText().trim();
            if (!HospitalData.doctorIdExists(id)) {
                JOptionPane.showMessageDialog(this, "Select a valid doctor to delete.", "Error", JOptionPane.WARNING_MESSAGE);
                return;
            }

            int ok = JOptionPane.showConfirmDialog(this, "Delete doctor " + id + "?", "Confirm", JOptionPane.YES_NO_OPTION);
            if (ok == JOptionPane.YES_OPTION) {
                HospitalData.deleteDoctor(id);
                loadTable(HospitalData.getDoctors());
                clearForm();
                JOptionPane.showMessageDialog(this, "Doctor deleted.", "Deleted", JOptionPane.INFORMATION_MESSAGE);
            }
        });

        btnClear.addActionListener(e -> clearForm());
        btnSearch.addActionListener(e -> {
            String q = txtSearch.getText().trim();
            loadTable(q.isEmpty() ? HospitalData.getDoctors() : HospitalData.searchDoctors(q));
        });
        btnShowAll.addActionListener(e -> {
            txtSearch.setText("");
            loadTable(HospitalData.getDoctors());
        });

        add(main);
    }

    private void loadTable(ArrayList<Doctor> list) {
        tableModel.setRowCount(0);
        for (Doctor d : list) {
            tableModel.addRow(new Object[] { d.getId(), d.getName(), d.getSpecialization() });
        }
    }

    private void clearForm() {
        txtId.setText("");
        txtName.setText("");
        txtSpec.setText("");
        table.clearSelection();
        txtId.requestFocus();
    }
}
