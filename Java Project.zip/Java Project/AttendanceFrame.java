import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

/**
 * Staff Attendance Screen
 * Demonstrates:
 * - State tracking: Present / Absent
 * - Swing GUI: JTable, JButton, JOptionPane
 */
public class AttendanceFrame extends JFrame {
    private DashboardFrame dashboard;

    private DefaultTableModel tableModel;
    private JTable table;
    private JLabel lblSummary = new JLabel();

    public AttendanceFrame(DashboardFrame dashboard) {
        this.dashboard = dashboard;
        setTitle("Hospital Management System - Staff Attendance");
        setSize(700, 460);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        initUI();
        loadTable();
    }

    private void initUI() {
        JPanel main = new JPanel(new BorderLayout(10, 10));
        main.setBorder(BorderFactory.createEmptyBorder(10, 15, 10, 15));

        // Header
        JPanel top = new JPanel(new BorderLayout());
        JLabel lblTitle = new JLabel("STAFF ATTENDANCE ROSTER");
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 16));

        JButton btnBack = new JButton("<< Back to Dashboard");
        btnBack.addActionListener(e -> {
            if (dashboard != null) {
                dashboard.refreshStats();
                dashboard.setVisible(true);
            }
            dispose();
        });

        top.add(lblTitle, BorderLayout.WEST);
        top.add(btnBack, BorderLayout.EAST);
        main.add(top, BorderLayout.NORTH);

        // Center Table Card
        JPanel tableCard = new JPanel(new BorderLayout(8, 8));
        tableCard.setBorder(BorderFactory.createTitledBorder("Daily Duty Status"));

        tableModel = new DefaultTableModel(new String[] { "Staff ID", "Name", "Status" }, 0) {
            @Override
            public boolean isCellEditable(int r, int c) { return false; }
        };
        table = new JTable(tableModel);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        tableCard.add(new JScrollPane(table), BorderLayout.CENTER);

        // Bottom Controls
        JPanel bottom = new JPanel(new BorderLayout());
        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 8));

        JButton btnPresent = new JButton("Mark Present");
        JButton btnAbsent = new JButton("Mark Absent");
        JButton btnRefresh = new JButton("Refresh");

        btnPresent.setBackground(new Color(40, 120, 70));
        btnPresent.setForeground(Color.WHITE);
        btnAbsent.setBackground(new Color(180, 45, 45));
        btnAbsent.setForeground(Color.WHITE);

        btnPanel.add(btnPresent);
        btnPanel.add(btnAbsent);
        btnPanel.add(btnRefresh);

        lblSummary.setFont(new Font("Segoe UI", Font.BOLD, 12));
        lblSummary.setHorizontalAlignment(JLabel.CENTER);

        bottom.add(lblSummary, BorderLayout.NORTH);
        bottom.add(btnPanel, BorderLayout.SOUTH);
        tableCard.add(bottom, BorderLayout.SOUTH);

        main.add(tableCard, BorderLayout.CENTER);

        // Actions
        btnPresent.addActionListener(e -> updateStatus("Present"));
        btnAbsent.addActionListener(e -> updateStatus("Absent"));
        btnRefresh.addActionListener(e -> loadTable());

        add(main);
    }

    private void loadTable() {
        tableModel.setRowCount(0);
        for (Attendance a : HospitalData.getAttendanceList()) {
            tableModel.addRow(new Object[] { a.getStaffId(), a.getStaffName(), a.getStatus() });
        }
        lblSummary.setText("Total Staff: " + HospitalData.getStaffCount() + 
            " | Present: " + HospitalData.getPresentCount() + 
            " | Absent: " + HospitalData.getAbsentCount());
    }

    private void updateStatus(String status) {
        int row = table.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(this, "Select a staff member from the table.", "Selection Required", JOptionPane.WARNING_MESSAGE);
            return;
        }

        String id = tableModel.getValueAt(row, 0).toString();
        HospitalData.updateAttendance(id, status);
        loadTable();
        JOptionPane.showMessageDialog(this, "Staff " + id + " marked as " + status + ".", "Updated", JOptionPane.INFORMATION_MESSAGE);
    }
}
