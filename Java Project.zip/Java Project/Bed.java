/**
 * Demonstrates:
 * - Encapsulation
 * - State management: Available / Occupied
 */
public class Bed {
    private String roomNumber;
    private String bedNumber;
    private String status; // "Available" or "Occupied"

    public Bed(String roomNumber, String bedNumber, String status) {
        this.roomNumber = roomNumber;
        this.bedNumber = bedNumber;
        this.status = status;
    }

    public String getRoomNumber() { return roomNumber; }
    public void setRoomNumber(String roomNumber) { this.roomNumber = roomNumber; }

    public String getBedNumber() { return bedNumber; }
    public void setBedNumber(String bedNumber) { this.bedNumber = bedNumber; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public boolean isAvailable() {
        return "Available".equalsIgnoreCase(status);
    }
}
