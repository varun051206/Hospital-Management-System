/**
 * Demonstrates:
 * - Inheritance: Doctor extends Person
 * - Polymorphism: Overrides getRole()
 * - Encapsulation: specialization field
 */
public class Doctor extends Person {
    private String specialization;

    public Doctor(String id, String name, String specialization) {
        super(id, name);
        this.specialization = specialization;
    }

    public String getSpecialization() {
        return specialization;
    }

    public void setSpecialization(String specialization) {
        this.specialization = specialization;
    }

    @Override
    public String getRole() {
        return "Doctor";
    }
}
