import java.util.ArrayList;

/**
 * In-Memory Data Store for Academic Hospital Management System
 * Demonstrates:
 * - Collections: ArrayList<T> for storing application objects
 * - Method Overloading: searchPatients(String) and searchPatients(int)
 * - Complete CRUD helper operations without any external database
 */
public class HospitalData {
    private static ArrayList<Patient> patients = new ArrayList<>();
    private static ArrayList<Doctor> doctors = new ArrayList<>();
    private static ArrayList<Staff> staffList = new ArrayList<>();
    private static ArrayList<Medicine> medicines = new ArrayList<>();
    private static ArrayList<Bed> beds = new ArrayList<>();
    private static ArrayList<Bill> bills = new ArrayList<>();
    private static ArrayList<Attendance> attendanceList = new ArrayList<>();

    static {
        // 1. 20 Fictional Indian Demo Patients
        patients.add(new Patient("P001", "Aarav Sharma", 34, "Male", "Cardiology"));
        patients.add(new Patient("P002", "Priya Patel", 28, "Female", "Dermatology"));
        patients.add(new Patient("P003", "Rajesh Kumar", 52, "Male", "General Medicine"));
        patients.add(new Patient("P004", "Ananya Iyer", 22, "Female", "Pediatrics"));
        patients.add(new Patient("P005", "Vikram Singh", 45, "Male", "Orthopedics"));
        patients.add(new Patient("P006", "Sunita Rao", 60, "Female", "Neurology"));
        patients.add(new Patient("P007", "Rohan Verma", 19, "Male", "ENT"));
        patients.add(new Patient("P008", "Deepa Nair", 31, "Female", "Oncology"));
        patients.add(new Patient("P009", "Amit Joshi", 41, "Male", "Cardiology"));
        patients.add(new Patient("P010", "Meera Reddy", 36, "Female", "General Medicine"));
        patients.add(new Patient("P011", "Suresh Gupta", 58, "Male", "Orthopedics"));
        patients.add(new Patient("P012", "Kavita Pillai", 25, "Female", "Dermatology"));
        patients.add(new Patient("P013", "Arjun Deshmukh", 49, "Male", "Neurology"));
        patients.add(new Patient("P014", "Pooja Das", 29, "Female", "General Medicine"));
        patients.add(new Patient("P015", "Manoj Kulkarni", 63, "Male", "Cardiology"));
        patients.add(new Patient("P016", "Divya Menon", 38, "Female", "ENT"));
        patients.add(new Patient("P017", "Sanjay Chauhan", 47, "Male", "Oncology"));
        patients.add(new Patient("P018", "Neha Bhat", 33, "Female", "Orthopedics"));
        patients.add(new Patient("P019", "Rakesh Sen", 55, "Male", "General Medicine"));
        patients.add(new Patient("P020", "Swati Mukherjee", 27, "Female", "Pediatrics"));

        // 2. 5 Fictional Doctors
        doctors.add(new Doctor("D001", "Dr. Arvind Swaminathan", "Cardiology"));
        doctors.add(new Doctor("D002", "Dr. Radhika Nair", "Dermatology"));
        doctors.add(new Doctor("D003", "Dr. Vivek Sengupta", "General Medicine"));
        doctors.add(new Doctor("D004", "Dr. Anjali Mehta", "Pediatrics"));
        doctors.add(new Doctor("D005", "Dr. Karthik Raman", "Orthopedics"));

        // 3. 5 Fictional Staff
        staffList.add(new Staff("S001", "Lakshmi Narayanan", "Head Nurse"));
        staffList.add(new Staff("S002", "Ramesh Kadam", "Pharmacist"));
        staffList.add(new Staff("S003", "Bhavna Trivedi", "Staff Nurse"));
        staffList.add(new Staff("S004", "Gopal Choudhary", "Lab Technician"));
        staffList.add(new Staff("S005", "Ankita Saxena", "Receptionist"));

        // 4. 6 Fictional Medicines (varied stock including Low Stock < 20)
        medicines.add(new Medicine("M001", "Paracetamol 500mg", 150, 20.0));
        medicines.add(new Medicine("M002", "Amoxicillin 250mg", 80, 55.0));
        medicines.add(new Medicine("M003", "Azithromycin 500mg", 15, 120.0)); // Low Stock (<20)
        medicines.add(new Medicine("M004", "Metformin 500mg", 95, 30.0));
        medicines.add(new Medicine("M005", "Omeprazole 20mg", 18, 45.0));   // Low Stock (<20)
        medicines.add(new Medicine("M006", "Cetirizine 10mg", 120, 15.0));

        // 5. 6 Beds across 3 Rooms
        beds.add(new Bed("101", "Bed 01", "Available"));
        beds.add(new Bed("101", "Bed 02", "Occupied"));
        beds.add(new Bed("102", "Bed 01", "Available"));
        beds.add(new Bed("102", "Bed 02", "Occupied"));
        beds.add(new Bed("103", "Bed 01", "Available"));
        beds.add(new Bed("103", "Bed 02", "Available"));

        // 6. 5 Sample Bills
        bills.add(new Bill("B001", "P001", 500, 1000, 750));
        bills.add(new Bill("B002", "P002", 400, 0, 350));
        bills.add(new Bill("B003", "P003", 600, 2000, 1100));
        bills.add(new Bill("B004", "P004", 500, 1500, 450));
        bills.add(new Bill("B005", "P005", 500, 1200, 600));

        // 7. 5 Staff Attendance Records
        attendanceList.add(new Attendance("S001", "Lakshmi Narayanan", "Present"));
        attendanceList.add(new Attendance("S002", "Ramesh Kadam", "Present"));
        attendanceList.add(new Attendance("S003", "Bhavna Trivedi", "Present"));
        attendanceList.add(new Attendance("S004", "Gopal Choudhary", "Absent"));
        attendanceList.add(new Attendance("S005", "Ankita Saxena", "Present"));
    }

    // --- PATIENTS ---
    public static ArrayList<Patient> getPatients() { return patients; }
    public static int getPatientCount() { return patients.size(); }

    public static boolean patientIdExists(String id) {
        for (Patient p : patients) {
            if (p.getId().equalsIgnoreCase(id.trim())) return true;
        }
        return false;
    }

    public static void addPatient(Patient p) { patients.add(p); }

    public static boolean updatePatient(Patient p) {
        for (int i = 0; i < patients.size(); i++) {
            if (patients.get(i).getId().equalsIgnoreCase(p.getId())) {
                patients.set(i, p);
                return true;
            }
        }
        return false;
    }

    public static boolean deletePatient(String id) {
        return patients.removeIf(p -> p.getId().equalsIgnoreCase(id.trim()));
    }

    // METHOD OVERLOADING 1: search by name or ID
    public static ArrayList<Patient> searchPatients(String query) {
        ArrayList<Patient> list = new ArrayList<>();
        String q = query.trim().toLowerCase();
        for (Patient p : patients) {
            if (p.getId().toLowerCase().contains(q) || p.getName().toLowerCase().contains(q)) {
                list.add(p);
            }
        }
        return list;
    }

    // METHOD OVERLOADING 2: search by exact age
    public static ArrayList<Patient> searchPatients(int age) {
        ArrayList<Patient> list = new ArrayList<>();
        for (Patient p : patients) {
            if (p.getAge() == age) list.add(p);
        }
        return list;
    }

    // --- DOCTORS ---
    public static ArrayList<Doctor> getDoctors() { return doctors; }
    public static int getDoctorCount() { return doctors.size(); }

    public static boolean doctorIdExists(String id) {
        for (Doctor d : doctors) {
            if (d.getId().equalsIgnoreCase(id.trim())) return true;
        }
        return false;
    }

    public static void addDoctor(Doctor d) { doctors.add(d); }

    public static boolean updateDoctor(Doctor d) {
        for (int i = 0; i < doctors.size(); i++) {
            if (doctors.get(i).getId().equalsIgnoreCase(d.getId())) {
                doctors.set(i, d);
                return true;
            }
        }
        return false;
    }

    public static boolean deleteDoctor(String id) {
        return doctors.removeIf(d -> d.getId().equalsIgnoreCase(id.trim()));
    }

    public static ArrayList<Doctor> searchDoctors(String query) {
        ArrayList<Doctor> list = new ArrayList<>();
        String q = query.trim().toLowerCase();
        for (Doctor d : doctors) {
            if (d.getId().toLowerCase().contains(q) || d.getName().toLowerCase().contains(q) || d.getSpecialization().toLowerCase().contains(q)) {
                list.add(d);
            }
        }
        return list;
    }

    // --- STAFF ---
    public static ArrayList<Staff> getStaffList() { return staffList; }
    public static int getStaffCount() { return staffList.size(); }

    public static boolean staffIdExists(String id) {
        for (Staff s : staffList) {
            if (s.getId().equalsIgnoreCase(id.trim())) return true;
        }
        return false;
    }

    public static void addStaff(Staff s) {
        staffList.add(s);
        attendanceList.add(new Attendance(s.getId(), s.getName(), "Present"));
    }

    public static boolean updateStaff(Staff s) {
        for (int i = 0; i < staffList.size(); i++) {
            if (staffList.get(i).getId().equalsIgnoreCase(s.getId())) {
                staffList.set(i, s);
                return true;
            }
        }
        return false;
    }

    public static boolean deleteStaff(String id) {
        attendanceList.removeIf(a -> a.getStaffId().equalsIgnoreCase(id.trim()));
        return staffList.removeIf(s -> s.getId().equalsIgnoreCase(id.trim()));
    }

    public static ArrayList<Staff> searchStaff(String query) {
        ArrayList<Staff> list = new ArrayList<>();
        String q = query.trim().toLowerCase();
        for (Staff s : staffList) {
            if (s.getId().toLowerCase().contains(q) || s.getName().toLowerCase().contains(q) || s.getStaffRole().toLowerCase().contains(q)) {
                list.add(s);
            }
        }
        return list;
    }

    // --- MEDICINES ---
    public static ArrayList<Medicine> getMedicines() { return medicines; }
    public static int getMedicineCount() { return medicines.size(); }

    public static boolean medicineIdExists(String id) {
        for (Medicine m : medicines) {
            if (m.getId().equalsIgnoreCase(id.trim())) return true;
        }
        return false;
    }

    public static void addMedicine(Medicine m) { medicines.add(m); }

    public static boolean updateMedicine(Medicine m) {
        for (int i = 0; i < medicines.size(); i++) {
            if (medicines.get(i).getId().equalsIgnoreCase(m.getId())) {
                medicines.set(i, m);
                return true;
            }
        }
        return false;
    }

    public static boolean deleteMedicine(String id) {
        return medicines.removeIf(m -> m.getId().equalsIgnoreCase(id.trim()));
    }

    public static boolean stockIn(String id, int qty) {
        for (Medicine m : medicines) {
            if (m.getId().equalsIgnoreCase(id.trim())) {
                m.setQuantity(m.getQuantity() + qty);
                return true;
            }
        }
        return false;
    }

    public static boolean stockOut(String id, int qty) {
        for (Medicine m : medicines) {
            if (m.getId().equalsIgnoreCase(id.trim())) {
                if (m.getQuantity() >= qty) {
                    m.setQuantity(m.getQuantity() - qty);
                    return true;
                }
                return false;
            }
        }
        return false;
    }

    public static ArrayList<Medicine> searchMedicines(String query) {
        ArrayList<Medicine> list = new ArrayList<>();
        String q = query.trim().toLowerCase();
        for (Medicine m : medicines) {
            if (m.getId().toLowerCase().contains(q) || m.getName().toLowerCase().contains(q)) {
                list.add(m);
            }
        }
        return list;
    }

    // --- BEDS ---
    public static ArrayList<Bed> getBeds() { return beds; }
    public static int getBedCount() { return beds.size(); }

    public static int getAvailableBedCount() {
        int count = 0;
        for (Bed b : beds) if (b.isAvailable()) count++;
        return count;
    }

    public static int getOccupiedBedCount() {
        return getBedCount() - getAvailableBedCount();
    }

    public static boolean allocateBed(String roomNo, String bedNo) {
        for (Bed b : beds) {
            if (b.getRoomNumber().equalsIgnoreCase(roomNo.trim()) && b.getBedNumber().equalsIgnoreCase(bedNo.trim())) {
                if (b.isAvailable()) {
                    b.setStatus("Occupied");
                    return true;
                }
                return false;
            }
        }
        return false;
    }

    public static boolean releaseBed(String roomNo, String bedNo) {
        for (Bed b : beds) {
            if (b.getRoomNumber().equalsIgnoreCase(roomNo.trim()) && b.getBedNumber().equalsIgnoreCase(bedNo.trim())) {
                if (!b.isAvailable()) {
                    b.setStatus("Available");
                    return true;
                }
                return false;
            }
        }
        return false;
    }

    // --- BILLS ---
    public static ArrayList<Bill> getBills() { return bills; }
    public static int getBillCount() { return bills.size(); }
    public static void addBill(Bill b) { bills.add(b); }

    // --- ATTENDANCE ---
    public static ArrayList<Attendance> getAttendanceList() { return attendanceList; }

    public static void updateAttendance(String staffId, String status) {
        for (Attendance a : attendanceList) {
            if (a.getStaffId().equalsIgnoreCase(staffId.trim())) {
                a.setStatus(status);
                break;
            }
        }
    }

    public static int getPresentCount() {
        int c = 0;
        for (Attendance a : attendanceList) if (a.isPresent()) c++;
        return c;
    }

    public static int getAbsentCount() {
        return getStaffCount() - getPresentCount();
    }
}
