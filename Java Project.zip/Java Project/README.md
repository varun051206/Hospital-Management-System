# Hospital Management System — Java Swing PBL Prototype

**Course:** CS25C09 – JAVA Programming
**Team:** Team 12
**Class:** AI&DS / II B / III
**Academic Year:** 2026–2027 (Odd Semester)

---

## How to Compile and Run

Open a terminal / command prompt inside the project folder and run:

```bash
# Step 1 — Compile all source files
javac *.java

# Step 2 — Run the application
java Main
```

**Login credentials:**
| Username | Password |
|----------|----------|
| `admin`  | `admin123` |

To run the automated logic test suite:
```bash
java SystemTester
```
Expected result: **15 Passed, 0 Failed**

---

## Project Structure

```
Java Project/
│
├── Model Classes (Plain Java Objects)
│   ├── Person.java          — Abstract base class (Inheritance & Polymorphism)
│   ├── Patient.java         — Extends Person; patient details
│   ├── Doctor.java          — Extends Person; doctor details
│   ├── Staff.java           — Extends Person; staff details
│   ├── Medicine.java        — Pharmacy stock item
│   ├── Bed.java             — Individual bed with occupancy status
│   ├── Room.java            — Room holding a list of beds
│   ├── Bill.java            — Billing record
│   └── Attendance.java      — Staff daily attendance record
│
├── Data Layer
│   └── HospitalData.java    — Central in-memory store (static ArrayLists + CRUD helpers)
│
├── GUI Frames (Java Swing)
│   ├── LoginFrame.java          — Login screen
│   ├── DashboardFrame.java      — Main dashboard with KPI cards & navigation
│   ├── PatientManagementFrame.java
│   ├── DoctorManagementFrame.java
│   ├── StaffManagementFrame.java
│   ├── PharmacyFrame.java
│   ├── RoomBedFrame.java
│   ├── BillingFrame.java
│   ├── AttendanceFrame.java
│   └── ReportsFrame.java
│
└── Entry Points
    ├── Main.java            — Launches the application
    └── SystemTester.java    — 15-point automated logic verification
```

---

## Module Details

### 1. Login (`LoginFrame.java`)
- Charcoal & Gold themed login window.
- Validates username + password; shows error on invalid credentials.
- Delegates to `DashboardFrame` on success.

### 2. Dashboard (`DashboardFrame.java`)
- Displays KPI summary cards: Patients, Doctors, Staff, Beds, Medicines, Bills.
- Navigation buttons to all 8 modules.
- Logout returns to Login.

### 3. Patient Management (`PatientManagementFrame.java`)
- 20 fictional Indian demo patients pre-loaded (`P001`–`P020`).
- Fields: Patient ID, Name, Age, Gender (JComboBox), Department (JComboBox).
- Operations: **Add**, **Update**, **Delete**, **Search** (by ID or Name), **Clear**.
- JTable with row-click auto-fill; validates input before saving.

### 4. Doctor Management (`DoctorManagementFrame.java`)
- 5 demo doctors (`D001`–`D005`) across departments.
- Fields: Doctor ID, Name, Department, Specialization, Contact.
- Operations: **Add**, **Update**, **Delete**, **Search**, **Clear**.

### 5. Staff Management (`StaffManagementFrame.java`)
- 5 demo staff members (`S001`–`S005`).
- Fields: Staff ID, Name, Role, Department, Phone.
- Operations: **Add**, **Update**, **Delete**, **Search**, **Clear**.

### 6. Pharmacy & Medicine Stock (`PharmacyFrame.java`)
- 6 demo medicines with quantity and expiry date.
- **Stock In (+):** Increases inventory count.
- **Stock Out (−):** Decreases count (prevents going below 0).
- Low Stock Alert: items with quantity < 20 flagged in bold red.
- Operations: **Add**, **Update**, **Delete**, **Search**, **Stock In**, **Stock Out**.

### 7. Room & Bed Allocation (`RoomBedFrame.java`)
- 3 rooms, 6–8 beds pre-loaded.
- Bed status: `Available` ↔ `Occupied`.
- **Allocate Bed**: Marks available bed as occupied; blocks double-allocation.
- **Release Bed**: Returns occupied bed to available.
- Live counters: Total / Available / Occupied.

### 8. Billing & Invoicing (`BillingFrame.java`)
- Inputs: Patient ID, Name, Consultation (₹), Room Charge (₹), Medicine Charge (₹).
- **Calculate Total**: `Total = Consultation + Room + Medicine`.
- **Save Bill**: Validates amounts and adds to the in-memory `ArrayList<Bill>`.

### 9. Attendance (`AttendanceFrame.java`)
- Daily duty roster for all staff.
- **Mark Present / Mark Absent**: Toggles attendance record for selected staff.
- Summary counts: Present Today vs Absent Today.

### 10. Reports (`ReportsFrame.java`)
- Summary statistics calculated live from all in-memory ArrayLists.
- Tabbed view: Patients | Medicines | Beds | Bills | Attendance.
- **Refresh** button re-fetches current data.

---

## Demo Data Summary

| Entity    | Count | ID Range         |
|-----------|-------|------------------|
| Patients  | 20    | P001 – P020      |
| Doctors   | 5     | D001 – D005      |
| Staff     | 5     | S001 – S005      |
| Medicines | 6     | M001 – M006      |
| Rooms     | 3     | R001 – R003      |
| Beds      | 6–8   | B01, B02, …      |

---

## Java Concepts for Viva

| Concept | Where Used |
|---|---|
| **Class & Object** | All model classes (`Patient`, `Doctor`, `Staff`, `Medicine`, `Bed`, `Bill`, `Attendance`) |
| **Abstract Class** | `Person.java` — abstract base with `getRole()` abstract method |
| **Inheritance** | `Patient`, `Doctor`, `Staff` all extend `Person` |
| **Polymorphism** | `Person p = new Patient(...)` → `p.getRole()` returns `"Patient"` |
| **Encapsulation** | Private fields with public getters/setters in all model classes |
| **Constructor** | Parameterized constructors in all model classes |
| **ArrayList** | `HospitalData.java` stores all entities in `ArrayList<T>` |
| **Method Overloading** | `searchPatients(String)` and `searchPatients(int age)` in `HospitalData` |
| **Exception Handling** | `try-catch (NumberFormatException)` when parsing age, stock qty, billing amounts |
| **Event Handling** | `ActionListener` on buttons, `ListSelectionListener` on JTable rows |
| **Swing Components** | `JFrame`, `JPanel`, `JLabel`, `JTextField`, `JPasswordField`, `JComboBox`, `JButton`, `JTable`, `JScrollPane`, `JTabbedPane`, `JOptionPane` |
| **State Management** | Bed: `Available ↔ Occupied`; Attendance: `Present ↔ Absent`; Stock in/out |

---

## Technology Stack

| Item | Details |
|---|---|
| Language | Java (Core Java) |
| UI | Java Swing + AWT |
| Data storage | In-memory `ArrayList` (no database) |
| IDE | VS Code |
| JDK | Java 8 or above |

> **No database.** No JDBC. No MySQL. No external frameworks. Pure Java.

---

## Code Size (Final Simplified Version)

| File | Lines |
|---|---|
| HospitalData.java | ~297 |
| PharmacyFrame.java | ~241 |
| PatientManagementFrame.java | ~218 |
| DoctorManagementFrame.java | ~169 |
| StaffManagementFrame.java | ~169 |
| BillingFrame.java | ~153 |
| RoomBedFrame.java | ~126 |
| DashboardFrame.java | ~118 |
| AttendanceFrame.java | ~97 |
| SystemTester.java | ~96 |
| ReportsFrame.java | ~90 |
| LoginFrame.java | ~77 |
| Model classes (9 files) | ~231 |
| **Total** | **~2,100 lines** |

---

## Automated Test Results

```
=========================================================
   HOSPITAL MANAGEMENT SYSTEM - CORE LOGIC TEST SUITE
=========================================================
[PASS]  1. Login Validation (admin / admin123)
[PASS]  2. Initial 20 Demo Patients Loaded
[PASS]  3. Patient Add and Search
[PASS]  4. Method Overloading: searchPatients(age 25)
[PASS]  5. Patient Delete
[PASS]  6. Doctor Add and Search
[PASS]  7. Staff Roster Loaded
[PASS]  8. Pharmacy Stock In & Stock Out
[PASS]  9. Prevent Stock Out Exceeding Available Stock
[PASS] 10. Low Stock Detection (< 20 units)
[PASS] 11. Bed Allocation and Release State Tracking
[PASS] 12. Billing Formula: consultation + room + medicine = 2250
[PASS] 13. Attendance Toggle (Present / Absent)
[PASS] 14. OOP Polymorphism: person.getRole()
[PASS] 15. Reports In-Memory Metric Aggregation
=========================================================
TEST RESULTS: 15 Passed, 0 Failed.
=========================================================
```
