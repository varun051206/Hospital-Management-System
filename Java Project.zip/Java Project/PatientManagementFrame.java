import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

/**
 * Patient Management Screen
 * Demonstrates:
 * - Swing GUI: JTextField, JComboBox, JTable, JScrollPane, JButton
 * - Event Handling: ActionListener and Table selection
 * - Exception Handling: NumberFormatException on age input
 * - In-Memory CRUD operations on ArrayList<Patient>
 */
public class PatientManagementFrame extends JFrame {
    private DashboardFrame dashboard;

    private JTextField txtId = new JTextField();
    private JTextField txtName = new JTextField();
    private JTextField txtAge = new JTextField();
    private JComboBox<String> cmbGender = new JComboBox<>(new String[] { "Male", "Female", "Other" });
    private JComboBox<String> cmbDept = new JComboBox<>(new String[] {
        "Cardiology", "Dermatology", "General Medicine", "Pediatrics", "Orthopedics", "Neurology", "ENT", "Oncology"
    });

    private JTextField txtSearch = new JTextField(12);
    private DefaultTableModel tableModel;
    private JTable table;

    public PatientManagementFrame(DashboardFrame dashboard) {
        this.dashboard = dashboard;
        setTitle("Hospital Management System - Patient Management");
        setSize(920, 560);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        initUI();
        loadTable(HospitalData.getPatients());
    }

    private void initUI() {
        JPanel main = new JPanel(new BorderLayout(10, 10));
        main.setBorder(BorderFactory.createEmptyBorder(10, 15, 10, 15));

        // Header
        JPanel top = new JPanel(new BorderLayout());
        JLabel lblTitle = new JLabel("PATIENT MANAGEMENT MODULE");
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 16));

        JButton btnBack = new JButton("<< Back to Dashboard");
        btnBack.addActionListener(e -> {
            if (dashboard != null) {
                dashboard.refreshStats();
                dashboard.setVisible(true);
            }
            dispose();
        });

        top.add(lblTitle, BorderLayout.WEST);
        top.add(btnBack, BorderLayout.EAST);
        main.add(top, BorderLayout.NORTH);

        // Center split: Form on Left, Table on Right
        JPanel body = new JPanel(new BorderLayout(15, 10));

        // Left Form Panel
        JPanel formCard = new JPanel(new BorderLayout());
        formCard.setPreferredSize(new Dimension(300, 400));
        formCard.setBorder(BorderFactory.createTitledBorder("Patient Form"));

        JPanel formFields = new JPanel(new GridLayout(5, 2, 8, 10));
        formFields.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        formFields.add(new JLabel("Patient ID:"));
        formFields.add(txtId);
        formFields.add(new JLabel("Full Name:"));
        formFields.add(txtName);
        formFields.add(new JLabel("Age:"));
        formFields.add(txtAge);
        formFields.add(new JLabel("Gender:"));
        formFields.add(cmbGender);
        formFields.add(new JLabel("Department:"));
        formFields.add(cmbDept);
        formCard.add(formFields, BorderLayout.CENTER);

        // Form Buttons
        JPanel formBtns = new JPanel(new GridLayout(2, 2, 6, 6));
        JButton btnAdd = new JButton("Add");
        JButton btnUpdate = new JButton("Update");
        JButton btnDelete = new JButton("Delete");
        JButton btnClear = new JButton("Clear");

        formBtns.add(btnAdd);
        formBtns.add(btnUpdate);
        formBtns.add(btnDelete);
        formBtns.add(btnClear);
        formCard.add(formBtns, BorderLayout.SOUTH);

        body.add(formCard, BorderLayout.WEST);

        // Right Table Panel
        JPanel tableCard = new JPanel(new BorderLayout(8, 8));
        tableCard.setBorder(BorderFactory.createTitledBorder("Patient Records"));

        // Search Bar
        JPanel searchBar = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 4));
        JButton btnSearch = new JButton("Search");
        JButton btnShowAll = new JButton("Show All");
        searchBar.add(new JLabel("Search (ID/Name):"));
        searchBar.add(txtSearch);
        searchBar.add(btnSearch);
        searchBar.add(btnShowAll);
        tableCard.add(searchBar, BorderLayout.NORTH);

        // Table
        String[] cols = { "ID", "Name", "Age", "Gender", "Department" };
        tableModel = new DefaultTableModel(cols, 0) {
            @Override
            public boolean isCellEditable(int row, int col) { return false; }
        };
        table = new JTable(tableModel);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        tableCard.add(new JScrollPane(table), BorderLayout.CENTER);

        body.add(tableCard, BorderLayout.CENTER);
        main.add(body, BorderLayout.CENTER);

        // Row click fills form
        table.getSelectionModel().addListSelectionListener(e -> {
            int row = table.getSelectedRow();
            if (row != -1) {
                txtId.setText(tableModel.getValueAt(row, 0).toString());
                txtName.setText(tableModel.getValueAt(row, 1).toString());
                txtAge.setText(tableModel.getValueAt(row, 2).toString());
                cmbGender.setSelectedItem(tableModel.getValueAt(row, 3).toString());
                cmbDept.setSelectedItem(tableModel.getValueAt(row, 4).toString());
            }
        });

        // Event Actions
        btnAdd.addActionListener(e -> addPatient());
        btnUpdate.addActionListener(e -> updatePatient());
        btnDelete.addActionListener(e -> deletePatient());
        btnClear.addActionListener(e -> clearForm());
        btnSearch.addActionListener(e -> searchPatients());
        btnShowAll.addActionListener(e -> {
            txtSearch.setText("");
            loadTable(HospitalData.getPatients());
        });

        add(main);
    }

    private void loadTable(ArrayList<Patient> list) {
        tableModel.setRowCount(0);
        for (Patient p : list) {
            tableModel.addRow(new Object[] {
                p.getId(), p.getName(), p.getAge(), p.getGender(), p.getDepartment()
            });
        }
    }

    private void addPatient() {
        String id = txtId.getText().trim();
        String name = txtName.getText().trim();
        String ageStr = txtAge.getText().trim();

        if (id.isEmpty() || name.isEmpty() || ageStr.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter ID, Name, and Age.", "Validation Error", JOptionPane.WARNING_MESSAGE);
            return;
        }

        // Numeric age check with Exception Handling
        int age;
        try {
            age = Integer.parseInt(ageStr);
            if (age <= 0 || age > 130) {
                JOptionPane.showMessageDialog(this, "Age must be between 1 and 130.", "Validation Error", JOptionPane.WARNING_MESSAGE);
                return;
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Age must be a valid number.", "Number Format Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (HospitalData.patientIdExists(id)) {
            JOptionPane.showMessageDialog(this, "Patient ID \"" + id + "\" already exists!", "Duplicate ID", JOptionPane.ERROR_MESSAGE);
            return;
        }

        Patient p = new Patient(id, name, age, (String) cmbGender.getSelectedItem(), (String) cmbDept.getSelectedItem());
        HospitalData.addPatient(p);
        loadTable(HospitalData.getPatients());
        clearForm();
        JOptionPane.showMessageDialog(this, "Patient added successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
    }

    private void updatePatient() {
        String id = txtId.getText().trim();
        String name = txtName.getText().trim();
        String ageStr = txtAge.getText().trim();

        if (id.isEmpty() || !HospitalData.patientIdExists(id)) {
            JOptionPane.showMessageDialog(this, "Select an existing patient to update.", "Selection Error", JOptionPane.WARNING_MESSAGE);
            return;
        }

        try {
            int age = Integer.parseInt(ageStr);
            Patient p = new Patient(id, name, age, (String) cmbGender.getSelectedItem(), (String) cmbDept.getSelectedItem());
            HospitalData.updatePatient(p);
            loadTable(HospitalData.getPatients());
            JOptionPane.showMessageDialog(this, "Patient updated successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Age must be a valid number.", "Number Format Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void deletePatient() {
        String id = txtId.getText().trim();
        if (id.isEmpty() || !HospitalData.patientIdExists(id)) {
            JOptionPane.showMessageDialog(this, "Select a valid patient to delete.", "Selection Error", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(this, "Delete patient " + id + "?", "Confirm Delete", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            HospitalData.deletePatient(id);
            loadTable(HospitalData.getPatients());
            clearForm();
            JOptionPane.showMessageDialog(this, "Patient deleted successfully!", "Deleted", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    private void searchPatients() {
        String query = txtSearch.getText().trim();
        if (query.isEmpty()) {
            loadTable(HospitalData.getPatients());
        } else {
            loadTable(HospitalData.searchPatients(query));
        }
    }

    private void clearForm() {
        txtId.setText("");
        txtName.setText("");
        txtAge.setText("");
        cmbGender.setSelectedIndex(0);
        cmbDept.setSelectedIndex(0);
        table.clearSelection();
        txtId.requestFocus();
    }
}
