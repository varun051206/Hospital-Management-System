import javax.swing.*;
import java.awt.*;

/**
 * Consolidated Reports Screen
 * Demonstrates:
 * - Real-time data aggregation across all in-memory collections
 * - Swing GUI: JTextArea, JScrollPane, JButton
 */
public class ReportsFrame extends JFrame {
    private DashboardFrame dashboard;
    private JTextArea txtReport = new JTextArea();

    public ReportsFrame(DashboardFrame dashboard) {
        this.dashboard = dashboard;
        setTitle("Hospital Management System - Summary Reports");
        setSize(650, 480);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        initUI();
        generateReport();
    }

    private void initUI() {
        JPanel main = new JPanel(new BorderLayout(10, 10));
        main.setBorder(BorderFactory.createEmptyBorder(10, 15, 10, 15));

        // Header
        JPanel top = new JPanel(new BorderLayout());
        JLabel lblTitle = new JLabel("HOSPITAL SUMMARY & ANALYTICAL REPORT");
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 16));

        JButton btnBack = new JButton("<< Back to Dashboard");
        btnBack.addActionListener(e -> {
            if (dashboard != null) {
                dashboard.refreshStats();
                dashboard.setVisible(true);
            }
            dispose();
        });

        top.add(lblTitle, BorderLayout.WEST);
        top.add(btnBack, BorderLayout.EAST);
        main.add(top, BorderLayout.NORTH);

        // Center: Report Text Area inside Scroll Pane
        txtReport.setEditable(false);
        txtReport.setFont(new Font("Monospaced", Font.PLAIN, 13));
        txtReport.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        main.add(new JScrollPane(txtReport), BorderLayout.CENTER);

        // Bottom: Refresh Button
        JPanel bottom = new JPanel(new FlowLayout(FlowLayout.CENTER));
        JButton btnRefresh = new JButton("Refresh Report Data");
        btnRefresh.addActionListener(e -> {
            generateReport();
            JOptionPane.showMessageDialog(this, "Report refreshed!", "Refreshed", JOptionPane.INFORMATION_MESSAGE);
        });
        bottom.add(btnRefresh);
        main.add(bottom, BorderLayout.SOUTH);

        add(main);
    }

    private void generateReport() {
        StringBuilder sb = new StringBuilder();
        sb.append("=========================================================\n");
        sb.append("       HOSPITAL MANAGEMENT SYSTEM - CONSOLIDATED REPORT  \n");
        sb.append("=========================================================\n\n");

        sb.append(String.format("  * Total Registered Patients : %d\n", HospitalData.getPatientCount()));
        sb.append(String.format("  * Total Doctors On Duty     : %d\n", HospitalData.getDoctorCount()));
        sb.append(String.format("  * Total Hospital Staff      : %d\n", HospitalData.getStaffCount()));
        sb.append(String.format("  * Total Medicines In Stock  : %d\n", HospitalData.getMedicineCount()));
        sb.append(String.format("  * Total Inpatient Beds      : %d\n", HospitalData.getBedCount()));
        sb.append(String.format("  * Available Beds            : %d\n", HospitalData.getAvailableBedCount()));
        sb.append(String.format("  * Occupied Beds             : %d\n", HospitalData.getOccupiedBedCount()));
        sb.append(String.format("  * Total Invoices Generated  : %d\n", HospitalData.getBillCount()));
        sb.append(String.format("  * Staff Present Today       : %d\n", HospitalData.getPresentCount()));
        sb.append(String.format("  * Staff Absent Today        : %d\n\n", HospitalData.getAbsentCount()));

        sb.append("---------------------------------------------------------\n");
        sb.append("  DOCTORS LIST:\n");
        for (Doctor d : HospitalData.getDoctors()) {
            sb.append(String.format("    - [%s] %-25s (%s)\n", d.getId(), d.getName(), d.getSpecialization()));
        }

        sb.append("\n  LOW STOCK MEDICINES (< 20 units):\n");
        boolean hasLowStock = false;
        for (Medicine m : HospitalData.getMedicines()) {
            if (m.getQuantity() < 20) {
                sb.append(String.format("    - [%s] %-22s Qty: %d [ALERT]\n", m.getId(), m.getName(), m.getQuantity()));
                hasLowStock = true;
            }
        }
        if (!hasLowStock) sb.append("    None. All medicines adequately stocked.\n");

        sb.append("\n=========================================================\n");
        sb.append("  Report Generated Successfully from Live In-Memory Data.\n");
        sb.append("=========================================================\n");

        txtReport.setText(sb.toString());
        txtReport.setCaretPosition(0);
    }
}
